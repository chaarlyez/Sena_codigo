/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7;

import java.util.Scanner;

/**
 *
 * @author Charly
 */
public class Ejercicio7 {

    public static void main(String[] args) {
        int GB,MG,CD;
        Scanner teclado=new Scanner (System.in);
        System.out.println ("GIGABYTES");
        GB=teclado.nextInt();
        MG=GB*1024;
        CD=((MG/700)+1);
        System.out.println("NUMERO DE CDs " + CD);
    }
}
